# Claude Code 開発ルール

## 🎯 このプロジェクトについて

**テンプレート種別**: Fullstack（フルスタック）

用途：本格的なWebアプリ、ユーザー認証あり、データベースあり

このプロジェクトは、PC（Claude Desktop）とスマホ（Claudeアプリ）でシームレスに開発するための構成になっています。

---

## 📋 基本ルール

### ルール1：1セッション = 1機能

**必須：**
- 1回のセッションでは、1つの機能・タスクに集中する
- 複数の機能を依頼された場合は、優先順位を確認してから1つずつ対応

**例：**
```
❌ 悪い例：「認証と商品一覧と決済を作って」
✅ 良い例：「認証機能を作って。メール/パスワードログインを含めて」
```

---

### ルール2：セッション終了前に必ずコミット

**作業完了時の手順：**
1. 変更内容を確認
2. 適切なコミットメッセージでコミット
3. リモートにプッシュ
4. ユーザーに完了報告

**コミットメッセージ規約：**
```
feat: 新機能追加
fix: バグ修正
docs: ドキュメント更新
style: コードスタイル修正
refactor: リファクタリング
test: テスト追加・修正
chore: その他（設定変更など）
```

---

### ルール3：継続作業時のコンテキスト確認

スマホから継続する場合、または「続き」と言われた場合：

1. 現在のブランチとコミット履歴を確認
2. 直近の変更内容を要約して共有
3. 何を続けるか明確にしてから作業開始

**確認コマンド：**
```bash
git status
git log --oneline -5
```

---

### ルール4：作業開始時の状態報告

新しいセッション開始時に報告：
1. プロジェクトの現在の状態
2. DBスキーマの概要
3. 実装済みの機能
4. 未完了のタスクがあれば報告

---

### ルール5：データベース変更時の注意

**Prismaスキーマを変更した場合：**
```bash
# マイグレーション作成
npx prisma migrate dev --name 変更内容

# クライアント再生成
npx prisma generate
```

**本番環境への反映：**
```bash
npx prisma migrate deploy
```

---

## 🛠️ 技術スタック

- **フレームワーク**: Next.js 14+ (App Router)
- **言語**: TypeScript
- **スタイリング**: Tailwind CSS
- **データベース**: PostgreSQL (Railway)
- **ORM**: Prisma
- **認証**: NextAuth.js v5 (Auth.js)
- **デプロイ**: Railway

---

## 📁 プロジェクト構造

```
src/
├── app/
│   ├── api/
│   │   └── auth/        # NextAuth.js API
│   ├── (auth)/          # 認証ページ（ログイン等）
│   │   ├── login/
│   │   └── register/
│   ├── (main)/          # メインページ（認証後）
│   │   └── dashboard/
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── ui/              # 汎用UIパーツ
│   └── features/        # 機能別コンポーネント
├── lib/
│   ├── db.ts            # Prismaクライアント
│   └── auth.ts          # NextAuth設定
└── types/               # 型定義

prisma/
├── schema.prisma        # DBスキーマ
└── migrations/          # マイグレーション履歴
```

---

## 🚀 開発コマンド

```bash
# 開発サーバー起動
npm run dev

# データベース操作
npx prisma studio        # DB管理画面（GUI）
npx prisma migrate dev   # マイグレーション実行
npx prisma generate      # クライアント生成
npx prisma db push       # スキーマを直接反映（開発用）

# ビルド・デプロイ
npm run build            # 本番ビルド
```

---

## ⚙️ 環境変数

`.env.example` を `.env` にコピー：

```bash
cp .env.example .env
```

**必要な環境変数：**
- `DATABASE_URL` - PostgreSQL接続URL
- `NEXTAUTH_URL` - アプリのURL
- `NEXTAUTH_SECRET` - 認証用シークレット

---

## 📱 PC/スマホ連携

- **PC（Claude Desktop）**: DB設計、認証実装、複雑な機能
- **スマホ**: UI修正、バグ修正、軽微な変更

**重要**: セッション切り替え前に必ず `git push` すること！

---

## 🔐 認証について

NextAuth.js v5 を使用。以下の認証方法に対応：
- メール/パスワード（Credentials）
- Google OAuth（設定追加で有効化）
- GitHub OAuth（設定追加で有効化）

認証設定は `src/lib/auth.ts` で管理。
