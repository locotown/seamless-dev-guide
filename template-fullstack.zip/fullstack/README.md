# プロジェクト名

> このREADMEはテンプレートです。プロジェクトに合わせて編集してください。

## 概要

プロジェクトの説明をここに書く

## 技術スタック

- **フレームワーク**: Next.js 14 (App Router)
- **言語**: TypeScript
- **スタイリング**: Tailwind CSS
- **データベース**: PostgreSQL (Railway)
- **ORM**: Prisma
- **認証**: NextAuth.js v5

## セットアップ

### 1. 依存関係インストール

```bash
npm install
```

### 2. 環境変数設定

```bash
cp .env.example .env
```

`.env` を編集してデータベースURLなどを設定

### 3. データベースセットアップ

```bash
# マイグレーション実行
npx prisma migrate dev

# （オプション）Prisma Studioでデータ確認
npx prisma studio
```

### 4. 開発サーバー起動

```bash
npm run dev
```

http://localhost:3000 でアクセス

## デプロイ（Railway）

### 1. Railwayプロジェクト作成

Railway CLIまたはダッシュボードでプロジェクトを作成

### 2. PostgreSQL追加

RailwayダッシュボードでPostgreSQLを追加

### 3. 環境変数設定

必要な環境変数をRailwayに設定：
- `DATABASE_URL`（PostgreSQL追加時に自動設定）
- `NEXTAUTH_URL`
- `NEXTAUTH_SECRET`

### 4. デプロイ

```bash
railway up
```

## ディレクトリ構成

```
src/
├── app/
│   ├── api/auth/       # 認証API
│   ├── (auth)/         # 認証ページ
│   └── (main)/         # メインページ
├── components/         # コンポーネント
└── lib/               # ユーティリティ
    ├── auth.ts        # NextAuth設定
    └── db.ts          # Prismaクライアント

prisma/
├── schema.prisma      # DBスキーマ
└── migrations/        # マイグレーション
```

## 開発メモ

<!-- 開発中のメモをここに追記 -->
